#!/bin/bash

# Source ROS 2 setup
source /opt/ros/humble/setup.bash

# Source your ROS 2 workspace (if already built)
if [ -f ~/ros2_ws/install/setup.bash ]; then
    source ~/ros2_ws/install/setup.bash
fi

# Optional: Add ArduPilot Tools to PATH
export PATH=~/ardu_ws/ardupilot/Tools/autotest:$PATH

# Optional: Extend Gazebo model/plugin paths
export GZ_SIM_RESOURCE_PATH=~/gazebo_ws/models:$GZ_SIM_RESOURCE_PATH
export GAZEBO_PLUGIN_PATH=~/gazebo_ws/build:$GAZEBO_PLUGIN_PATH
export GAZEBO_MODEL_PATH=~/gazebo_ws/models:$GAZEBO_MODEL_PATH
