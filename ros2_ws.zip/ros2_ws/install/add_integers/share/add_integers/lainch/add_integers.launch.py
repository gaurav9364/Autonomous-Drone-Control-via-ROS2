from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
	service = Node(
		package="add_integers",
		executable="addition_service",
		name="addition_service",
	)

	client = Node(
		package="add_integers",
		executable="addition_client",
		name="addition_client",
	)

	return LaunchDescription([
		service,
		client
	])
