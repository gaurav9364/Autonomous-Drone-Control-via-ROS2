from launch import LaunchDescription
from launch_ros.actions import Node

from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    config_file = os.path.join(
        get_package_share_directory('drone_sitl_ros'),
        'config',
        'mavros_params.yaml'
    )

    return LaunchDescription([
        Node(
            package='mavros',
            executable='mavros_node',
            name='mavros',
            output='screen',
            parameters=[
                config_file,
                {'fcu_url': 'udp://:14540@127.0.0.1:14557'}
            ]
        )
    ])

