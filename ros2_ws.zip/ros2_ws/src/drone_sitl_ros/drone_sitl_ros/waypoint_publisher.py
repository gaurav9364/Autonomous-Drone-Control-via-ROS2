import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped

class WaypointPublisher(Node):
    def __init__(self):
        super().__init__('waypoint_publisher')
        self.publisher = self.create_publisher(PoseStamped, '/drone/setpoint', 10)
        self.timer = self.create_timer(5.0, self.timer_callback)
        self.index = 0
        self.waypoints = [
            (0, 0, 3),
            (10, 0, 3),
            (10, 10, 3),
            (0, 10, 3),
            (0, 0, 3)
        ]

    def timer_callback(self):
        if self.index >= len(self.waypoints):
            self.get_logger().info('All waypoints sent.')
            return

        wp = PoseStamped()
        wp.header.frame_id = "map"
        wp.pose.position.x = float(self.waypoints[self.index][0])
        wp.pose.position.y = float(self.waypoints[self.index][1])
        wp.pose.position.z = float(self.waypoints[self.index][2])

        self.publisher.publish(wp)
        self.get_logger().info(f'Sent waypoint {self.index + 1}')
        self.index += 1

def main(args=None):
    rclpy.init(args=args)
    node = WaypointPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
