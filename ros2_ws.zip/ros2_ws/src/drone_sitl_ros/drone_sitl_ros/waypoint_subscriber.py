import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped

class DronePoseLogger(Node):
    def __init__(self):
        super().__init__('drone_pose_logger')
        self.subscription = self.create_subscription(
            PoseStamped,
            '/mavros/local_position/pose',
            self.pose_callback,
            10
        )

    def pose_callback(self, msg):
        pos = msg.pose.position
        self.get_logger().info(f"Drone is at x: {pos.x:.2f}, y: {pos.y:.2f}, z: {pos.z:.2f}")

def main(args=None):
    rclpy.init(args=args)
    node = DronePoseLogger()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
