import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Pose, Twist
# from std_msgs.msg import Header
import airsim
# import time

class AirSimBridge(Node):
    def __init__(self):
        super().__init__('airsim_bridge')
        #Initializes the AirSim Multirotor API client, which connects to the running AirSim simulator.
        self.client = airsim.MultirotorClient()         
        #Confirms that the connection to AirSim was successful.
        self.client.confirmConnection()                 
        # Takes manual control of the drone via the API (disabling RC/manual user input).
        self.client.enableApiControl(True)
        # Arms the drone (i.e., prepares motors for takeoff).
        self.client.armDisarm(True)
        # Commands drone to take off asynchronously, and .join() waits for the takeoff to complete.
        self.client.takeoffAsync().join()
        # Logs a message to the ROS 2 console that the connection and takeoff succeeded.
        self.get_logger().info("Connected to AirSim and took off.")
        # self.pose_sub subscribes to /drone/pose_cmd (published by your ROS 2 publisher
        # 10 is the message queue size (buffer of up to 10 messages if the callback lags).
        self.pose_sub = self.create_subscription(Pose, '/drone/pose_cmd', self.pose_callback, 10)
        # self.twist_sub subscribes to /drone/vel_cmd for velocity control.
        self.twist_sub = self.create_subscription(Twist, '/drone/vel_cmd', self.velocity_callback, 10)

        # Publishes telemetry from AirSim:
            # /drone/position: Drone’s current position (as a Pose).
            # /drone/velocity: Drone’s current linear velocity (as a Twist).
        self.position_pub = self.create_publisher(Pose, '/drone/position', 10)
        self.velocity_pub = self.create_publisher(Twist, '/drone/velocity', 10)
        # Creates a ROS 2 timer that triggers publish_telemetry() every 1 second.
            # This function fetches drone state from AirSim and publishes it to ROS.
        self.timer = self.create_timer(1.0, self.publish_telemetry)


    # Triggered when a new position command is received on /drone/pose_cmd.
    # Sends the drone to (x, y, z) at 2 m/s using moveToPositionAsync().
    # .join() blocks until the movement finishes.
    # Logs the target position.
    def pose_callback(self, msg):
        self.client.moveToPositionAsync(
            msg.position.x,
            msg.position.y,
            msg.position.z,
            velocity=3.0,
            drivetrain=airsim.DrivetrainType.ForwardOnly,
            yaw_mode=airsim.YawMode(is_rate=False, yaw_or_rate=0),
            timeout_sec=60
        )
        self.get_logger().info(f'Sent position command to x:{msg.position.x} y:{msg.position.y} z:{msg.position.z}')
    # Triggered on receiving a Twist message on /drone/vel_cmd.
    # Sends drone velocity command (in body frame) for 1 second.
    # Uses YawMode with is_rate=True so angular.z is interpreted as yaw rate (radians/sec).
    def velocity_callback(self, msg):
        self.client.moveByVelocityAsync(msg.linear.x, msg.linear.y, msg.linear.z, duration=1.0,
                                        yaw_mode=airsim.YawMode(is_rate=True, yaw_or_rate=msg.angular.z))
        self.get_logger().info(f'Velocity command x:{msg.linear.x} y:{msg.linear.y} z:{msg.linear.z}')
    

    # Gets current multirotor state from AirSim (includes position, velocity, orientation, etc.)
    def publish_telemetry(self):
        state = self.client.getMultirotorState()
        # Fills a Pose message with the current position.
        # x_val, y_val, z_val are AirSim’s current coordinates (NED frame).
        pos_msg = Pose()
        pos_msg.position.x = state.kinematics_estimated.position.x_val
        pos_msg.position.y = state.kinematics_estimated.position.y_val
        pos_msg.position.z = state.kinematics_estimated.position.z_val
        # Fills a Twist message with current linear velocity.
        twist_msg = Twist()
        twist_msg.linear.x = state.kinematics_estimated.linear_velocity.x_val
        twist_msg.linear.y = state.kinematics_estimated.linear_velocity.y_val
        twist_msg.linear.z = state.kinematics_estimated.linear_velocity.z_val
        # Publishes the telemetry data to the respective ROS topics every 1 second.
        self.position_pub.publish(pos_msg)
        self.velocity_pub.publish(twist_msg)

def main(args=None):
    rclpy.init(args=args)
    node = AirSimBridge()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

