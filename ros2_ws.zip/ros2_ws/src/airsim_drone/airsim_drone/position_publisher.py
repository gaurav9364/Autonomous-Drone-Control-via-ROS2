import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Pose, Twist     # Pose- We use it to command where the drone should go.  Twist- You use it to command how fast and in what direction the drone should move.
# import time

class DroneCommandPublisher(Node):
    def __init__(self):
        super().__init__('drone_command_publisher')
        self.pose_pub = self.create_publisher(Pose, '/drone/pose_cmd', 10)
        # self.vel_pub = self.create_publisher(Twist, '/drone/vel_cmd', 10)
        # Waypoints in (x, y, z). z is altitude (AirSim uses NED, so it's negative).
        self.waypoints = [
            (0.0, 0.0, -26.0),
            (100.0, 0.0, -26.0),
            (100.0, 100.0, -26.0),
            (0.0, 90.0, -26.0),
            (0.0, 0.0, -26.0)  # back to start
        ]

        self.index = 0
        self.timer = self.create_timer(6.0, self.publish_next_waypoint)

    def publish_next_waypoint(self):
        if self.index >= len(self.waypoints):
            self.get_logger().info("All waypoints sent. Stopping.")
            self.timer.cancel()
            return

        x, y, z = self.waypoints[self.index]
        pose = Pose()
        pose.position.x = x
        pose.position.y = y
        pose.position.z = z

        self.pose_pub.publish(pose)
        self.get_logger().info(f"Published Waypoint #{self.index}: ({x}, {y}, {z})")
        self.index += 1

        # Publish velocity
        # twist = Twist()
        # twist.linear.x = 4.0  # move forward
        # twist.linear.y = 0.0
        # twist.linear.z = 0.0  # no change in height
        # twist.angular.z = 0.0  # no yaw
        # self.vel_pub.publish(twist)
        # self.get_logger().info(f"Published Velocity: x=4.0 z=0.0 (#{self.counter})")

   #     self.counter += 1
  #      if self.counter > 5:
 #           self.get_logger().info("Stopping publisher node after 5 messages.")
#            self.destroy_node()

        # # Publish velocity
        # twist = Twist()
        # twist.linear.x = 4.0
        # twist.linear.y = 0.0
        # twist.linear.z = -2.0
        # twist.angular.z = 0.0
        # self.vel_pub.publish(twist)
        # self.get_logger().info("Published velocity")

def main(args=None):
    rclpy.init(args=args)
    node = DroneCommandPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()


