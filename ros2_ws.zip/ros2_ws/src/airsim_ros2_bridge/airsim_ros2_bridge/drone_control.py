import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import airsim
import time

class AirSimDroneBridge(Node):
    def __init__(self):
        super().__init__('airsim_drone_bridge')
        self.subscription = self.create_subscription(Twist, '/cmd_vel', self.listener_callback, 10)
        self.client = airsim.MultirotorClient()
        self.client.confirmConnection()
        self.client.enableApiControl(True)
        self.client.armDisarm(True)
        self.client.takeoffAsync().join()
        self.get_logger().info("Drone ready to receive commands.")

    def listener_callback(self, msg):
        vx = msg.linear.x
        vy = msg.linear.y
        vz = msg.linear.z
        yaw_rate = msg.angular.z
        self.client.moveByVelocityAsync(vx, vy, vz, duration=20.0, yaw_mode=airsim.YawMode(is_rate=True, yaw_or_rate=yaw_rate))

def main(args=None):
    rclpy.init(args=args)
    node = AirSimDroneBridge()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
