# import rclpy
# from rclpy.node import Node
# from geometry_msgs.msg import Twist

# class DroneVelocityPublisher(Node):
#     def __init__(self):
#         super().__init__('drone_velocity_publisher')
#         self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)
#         timer_period = 0.5  # seconds
#         self.timer = self.create_timer(timer_period, self.timer_callback)
#         self.get_logger().info('Velocity publisher started.')

#     def timer_callback(self):
#         msg = Twist()
#         msg.linear.z = 1.0  # To increase altitude
#         msg.linear.x = 0.0
#         msg.linear.y = 0.0
#         msg.angular.z = 0.0
#         self.publisher_.publish(msg)
#         self.get_logger().info(f'Publishing: {msg}')

# def main(args=None):
#     rclpy.init(args=args)
#     node = DroneVelocityPublisher()
#     rclpy.spin(node)
#     node.destroy_node()
#     rclpy.shutdown()

# if __name__ == '__main__':
#     main()
